package com.example.myapplication.mainPage

class TagLine(var tag1: String, var tag2: String, var tag3: String) {
}