package com.example.myapplication.mainPage

import androidx.appcompat.app.AppCompatActivity

class SikdangList: AppCompatActivity() {
}