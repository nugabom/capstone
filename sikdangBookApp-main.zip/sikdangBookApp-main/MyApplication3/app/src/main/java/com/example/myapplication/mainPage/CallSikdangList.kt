package com.example.myapplication.mainPage

class CallSikdangList(val dist:Float, val cat:String) {

    private fun setDist(){

    }
}